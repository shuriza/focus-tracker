import { formatDuration } from "./lib.js";

const domainEl = document.getElementById("domain");
const usageEl = document.getElementById("usage");
const quoteEl = document.getElementById("quote");
const sessionEl = document.getElementById("session");
const statusEl = document.getElementById("status");
const sessionBoxEl = sessionEl.closest(".session-box");
const syncEl = document.getElementById("sync");
const signoutEl = document.getElementById("signout");
const budgetTotalEl = document.getElementById("budget-total");
const budgetTrackEl = document.getElementById("budget-track");
const budgetBarEl = document.getElementById("budget-bar");
const budgetDetailEl = document.getElementById("budget-detail");

function renderBudget(budget) {
  if (!budget || budget.budgetMinutes == null) {
    budgetTotalEl.textContent = "Anggaran belum diatur.";
    budgetTrackEl.hidden = true;
    budgetBarEl.style.width = "0%";
    budgetBarEl.classList.remove("over");
    budgetDetailEl.classList.remove("over");
    budgetDetailEl.textContent = "Atur anggaran harian di dashboard Fokus Kerja.";
    return;
  }

  budgetTotalEl.textContent = `${formatDuration(budget.usedSeconds)} / ${formatDuration(budget.budgetMinutes * 60)}`;
  budgetTrackEl.hidden = false;
  budgetBarEl.style.width = `${Math.round(budget.ratio * 100)}%`;
  budgetBarEl.classList.toggle("over", budget.over);
  budgetDetailEl.classList.toggle("over", budget.over);
  budgetDetailEl.textContent = budget.over
    ? `Lewat ${formatDuration(budget.usedSeconds - budget.budgetMinutes * 60)} dari anggaran.`
    : `Sisa ${formatDuration(budget.remainingSeconds)} hari ini.`;
}

function render(status) {
  if (!status.domain) {
    domainEl.textContent = "Tidak ada tab tercatat";
    usageEl.textContent = "Buka situs http/https untuk mulai timer.";
    quoteEl.hidden = true;
  } else {
    domainEl.textContent = status.domain;
    let suffix = " · tanpa kuota";
    if (status.ruleStatus === "inactive") {
      suffix = " · kuota nonaktif";
    } else if (status.limitMinutes) {
      suffix = ` dari ${status.limitMinutes} menit`;
    }
    usageEl.textContent = `${formatDuration(status.usedSeconds)}${suffix}${status.blocked ? " · diblokir" : ""}`;
    if (status.blocked) {
      quoteEl.hidden = false;
      quoteEl.textContent = status.quote;
    } else {
      quoteEl.hidden = true;
    }
  }
  sessionEl.textContent = status.signedIn
    ? `Sesi aktif: ${status.email}`
    : "Belum tersinkron. Hubungkan akun untuk memuat aturan dan analitik.";
  sessionBoxEl.classList.toggle("connected", status.signedIn);
  syncEl.textContent = status.signedIn ? "Perbarui Data" : "Masuk & Sinkronkan";
  signoutEl.hidden = !status.signedIn;
  renderBudget(status.budget);
}

chrome.runtime.sendMessage({ type: "FOKUS_GET_STATUS" }, (status) => {
  if (chrome.runtime.lastError) {
    statusEl.textContent = chrome.runtime.lastError.message;
    return;
  }
  render(status);
});

syncEl.addEventListener("click", () => {
  syncEl.disabled = true;
  statusEl.textContent = "Menghubungkan ke dashboard...";
  chrome.runtime.sendMessage({ type: "FOKUS_SYNC_SESSION" }, (result) => {
    syncEl.disabled = false;
    if (chrome.runtime.lastError) {
      statusEl.textContent = chrome.runtime.lastError.message;
      return;
    }
    if (result?.ok) {
      statusEl.textContent = `Data diperbarui sebagai ${result.email}`;
    } else if (result?.reason === "login_required") {
      statusEl.textContent = "Selesaikan login di tab yang dibuka. Sesi akan tersinkron otomatis.";
    } else {
      statusEl.textContent = "Dashboard tidak dapat dihubungi. Coba lagi.";
    }
    chrome.runtime.sendMessage({ type: "FOKUS_GET_STATUS" }, render);
  });
});

signoutEl.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "FOKUS_SIGNOUT" }, () => {
    statusEl.textContent = "Sesi ekstensi diputus. Timer lokal tetap jalan.";
    chrome.runtime.sendMessage({ type: "FOKUS_GET_STATUS" }, render);
  });
});
